package com.biz.user;

import org.aspectj.lang.annotation.After;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Before;
import org.aspectj.lang.annotation.Pointcut;

@Aspect
public class LogAspect {
	public void logWrite() {
		System.out.println("log write");
	}
	
	@Pointcut("execution(public * com.biz.user.UserServiceImpl.*(..))")
    public void targetMethod() {
        // pointcut annotation 값을 참조하기 위한 dummy method
    }
	
	//@Pointcut("execution(* com.biz..*Impl.*(..))")
	//@Before("execution(public * com.biz.user.UserServiceImpl.*(..))")
	@Before("targetMethod()")
	public void prevCehck() {
		System.out.println("-----------prevCehck");
	}
	@After("targetMethod()")
	public void close() {
		System.out.println("-----------close"); 
	}

	
}
